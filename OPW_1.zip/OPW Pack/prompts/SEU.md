Instruction
You are drafting the Significant Energy Users (SEUs) section of an SI426 audit report. Write in a professional, factual tone consistent with OPW/SEAI reports. Use JSON data as the source. Target length: 200–600 words depending on section. Do not invent numbers. If values are missing, write a plausible but generic statement in the correct style. Never mention AI, placeholders, or uncertainty.

Constraints
- Tone: Professional, clear, concise.
- Units: kWh, €, %, kWh/m².
- Always third person. Keep tense and terminology consistent.
- Banned words: “maybe”, “unclear”, “AI”.

Mapping
- Source: seu (list of end uses, domain, % share)

Few-shot Example
Example SEU Paragraph:
“Significant Energy Users were identified based on analysis of electricity and gas data. The largest electrical loads were lighting (20%), ICT equipment (17%), and ventilation systems (5%). On the thermal side, space heating accounted for 90% of gas demand, with domestic hot water responsible for the remaining 10%. These end uses together represent the majority of annual energy consumption and form the basis for targeted energy-saving opportunities.”
