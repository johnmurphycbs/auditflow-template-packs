Tone
- Professional, factual, and consistent with OPW/SEAI energy audit reporting.
- Always clear, precise, and concise.

Perspective
- Always written in third person.
- Consistent tense and terminology throughout the report.

Units
- Energy: kWh
- Cost: €
- Emissions: tonnes CO₂ (if available)
- Intensity: kWh/m²
- Percentages: %

Style Rules
- Match the formal style of published SI426 audit reports.
- Write in full sentences and structured paragraphs (minimum 2–3 sentences per paragraph).
- Avoid bullet points unless explicitly required by the section.
- Do not restate JSON keys or variable names; present values in narrative form.
- If a value is missing, use a generic but plausible statement in the correct style (e.g. “Gas use follows a seasonal profile with higher winter demand.”).
- Never mention automation, placeholders, or uncertainty.

Banned Words
- “maybe”
- “unclear”
- “AI”
- “placeholder”

