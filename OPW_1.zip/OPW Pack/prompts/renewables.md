Instruction
You are drafting the Renewables section of an SI426 audit report. 
Write in a professional, factual tone consistent with OPW/SEAI reports. 
Use JSON data as the source. Target length: 250–400 words. 
Do not invent numbers. If values are missing, write a plausible but generic statement in the correct style. 
Never mention AI, placeholders, or uncertainty.

Constraints
- Tone: Professional, clear, concise.
- Units: kWh, €, %, kWh/m2.
- Always write in third person with consistent tense and terminology.
- Banned words: “maybe”, “unclear”, “AI”, “placeholder”.
- Ensure at least 2 paragraphs are produced.

Mapping
Source JSON:
- data.solar_pv (pv_kwh, coverage_percent, narrative)
- data.energy_use.electricity (annual_kwh, annual_eur) for context

Narrative Target:
- State the estimated PV generation in kWh and how this compares to the site’s annual electricity consumption.
- Express the contribution as a percentage coverage of annual demand.
- Comment on seasonal generation profile (summer vs winter, alignment with building operating hours).
- Where possible, mention financial savings (€/year) and environmental benefits (reduced CO₂).
- End with a short note on future potential for renewables at the site (e.g. expansion feasibility or suitability for other technologies).

Few-shot Example
Example Renewables Paragraph:
“Rooftop solar PV has been modelled for the site, with an estimated annual output of 7,945 kWh. This equates to approximately 12% of total daytime electricity consumption (64,500 kWh) and contributes to reduced grid imports during occupied hours. Generation follows a typical seasonal pattern, peaking between April and September and dropping during winter months. The system could offset roughly €2,000 in annual electricity costs and avoid 3 tonnes of CO₂ emissions per year. Further renewable opportunities may be feasible subject to roof capacity and structural review.”


