Instruction
You are drafting the Opportunities section of an SI426 audit report. 
Write in a professional, factual tone consistent with OPW/SEAI reports. 
Use JSON data as the source. Target length: 300–600 words. 
Do not invent numbers. If values are missing, write a plausible but generic statement in the correct style. 
Never mention AI, placeholders, or uncertainty.

Constraints
- Tone: Professional, clear, concise.
- Units: kWh, €, %, kWh/m2.
- Always write in third person with consistent tense and terminology.
- Banned words: “maybe”, “unclear”, “AI”, “placeholder”.
- Ensure each opportunity is described in at least 2–3 sentences.

Mapping
Source JSON:
- data.opportunities (each item may include: name, description, estimated_savings_kwh, estimated_savings_eur, payback_years, notes)

Narrative Target:
- For each opportunity:
  • Name the measure clearly.  
  • Describe what it involves (e.g. technology, system, behaviour change).  
  • If data exists, include estimated savings in kWh and € and mention simple payback.  
  • Comment on why it is appropriate for the site (link to SEUs, building type, or observed issues).  
- Write each measure as a short paragraph (100–200 words).  
- At the end, include a concluding sentence summarising how these measures collectively contribute to energy savings and carbon reduction.

Few-shot Example
Example Opportunities Paragraph:
“Lighting upgrades to high-efficiency LED with controls are recommended in circulation areas, classrooms, and offices. The upgrade would reduce both electrical demand and maintenance costs, with estimated savings of 12,000 kWh per year (approx. €2,500) and a payback of under 4 years. Heating control optimisation is also advised, including reduced setpoints and time scheduling implemented through the BMS. This measure addresses excessive heating observed during off-hours and could save 15,000 kWh annually, with no significant capital cost. Variable speed drives on fans and pumps are another option to reduce electrical demand, offering improved efficiency and better alignment of load with demand.”


