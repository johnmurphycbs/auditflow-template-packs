Instruction
You are drafting the Electricity section of an SI426 audit report. 
Write in a professional, factual tone consistent with OPW/SEAI reports. 
Use JSON data as the source. Target length: 250–400 words. 
Do not invent numbers. If values are missing, write a plausible but generic statement in the correct style. 
Never mention AI, placeholders, or uncertainty.

Constraints
- Tone: Professional, clear, concise.
- Units: kWh, €, %, kWh/m².
- Always write in third person with consistent tense and terminology.
- Banned words: “maybe”, “unclear”, “AI”, “placeholder”.
- Ensure at least 2–3 paragraphs are generated.

Mapping
Source JSON:
- data.energy_use.electricity.annual_kwh
- data.energy_use.electricity.annual_eur
- data.energy_use.electricity.months
- data.energy_use.electricity.peak_period
- data.energy_use.electricity.tou.day_kwh
- data.energy_use.electricity.tou.night_kwh
- data.energy_use.electricity.periods (for monthly trends)

Narrative Target:
- State the total annual consumption (kWh) and cost (€).
- Mention the number of billing months covered in the dataset.
- Identify the peak consumption month and discuss its significance.
- Describe the monthly trend, noting any seasonal variation (e.g. winter peaks, summer dips).
- Analyse the day vs night split, providing approximate percentages.
- Comment briefly on the implications for energy management (e.g. opportunities for shifting load or optimising base demand).

Few-shot Example
Example Electricity Paragraph:
“Annual electricity consumption was 213,000 kWh at a total cost of €27,600, based on 23 months of billing data. The highest consumption occurred in October, coinciding with extended heating and lighting demand as daylight hours reduced. Time-of-use analysis shows 55% of demand during the day and 45% at night, reflecting typical office occupancy and ICT loads operating outside hours. Consumption patterns are relatively consistent month to month, with modest increases during winter and lower baseload in summer. The data highlights opportunities to further manage out-of-hours demand and optimise base electrical loads.”


