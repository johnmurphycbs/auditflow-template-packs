Instruction
You are drafting the Opportunities Introduction of an SI426 audit report. 
Write in a professional, factual tone consistent with OPW/SEAI reports. 
Use JSON data as the source. Target length: 120–200 words. 
Do not invent numbers. If values are missing, write a plausible but generic statement in the correct style. 
Never mention AI, placeholders, or uncertainty.

Constraints
- Tone: Professional, clear, concise.
- Units: kWh, €, %, kWh/m2.
- Always third person with consistent tense and terminology.
- Banned words: “maybe”, “unclear”, “AI”, “placeholder”.
- Ensure at least one complete paragraph is produced.

Mapping
Source JSON:
- data.opportunities (list length, categories if present)

Narrative Target:
- Introduce the opportunities section clearly and neutrally.
- Mention how many opportunities have been identified and their general focus (fabric, lighting, heating, renewables, controls, etc.) if that detail exists.
- State that measures are intended to reduce energy use, carbon emissions, and cost, while maintaining service quality.
- End with a sentence setting up the detailed descriptions that follow.

Few-shot Example
Example Opportunities Introduction:
“A total of six opportunities have been identified to reduce energy use and carbon emissions at the site. These measures cover lighting, heating, controls, and renewable generation, reflecting the main energy consumers observed during the audit. All measures are designed to maintain comfort and service delivery while lowering operating costs. The following section provides a description of each opportunity, including indicative savings where available.”


