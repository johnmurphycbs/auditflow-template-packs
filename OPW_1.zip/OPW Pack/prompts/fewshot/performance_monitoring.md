Example 1:
“Electricity consumption was compared with degree day data, but no strong correlation was observed, indicating that demand is primarily driven by ICT and lighting loads rather than weather. In contrast, gas consumption showed a clear seasonal profile with higher usage during the heating season, although the regression coefficient was moderate due to irregular operation of boiler plant. R² values below 0.5 highlight the need for improved data quality and more consistent operational practices.

Energy intensity benchmarks were also reviewed, with the site recording a combined intensity of 40 kWh/m². This figure is within the expected range for education facilities but indicates scope for further optimisation. Sub-metering currently provides limited visibility of end-uses, with only main electricity and gas meters in place. Installation of additional sub-meters for ICT, ventilation, and heating circuits would enable more accurate tracking of Significant Energy Users (SEUs).”

Example 2:
“Regression analysis confirmed that gas use strongly follows external temperature, with high demand in January and February tapering to negligible levels in summer. The regression model achieved an R² of 0.72, reflecting reliable weather-driven heating loads. Electricity consumption did not correlate with degree days, as expected for a site with high base electrical demand. Instead, seasonal variation in electricity use was linked to lighting and auxiliary heating systems.

Performance monitoring would benefit from enhanced sub-metering and automated data collection through the BMS. At present, monthly utility invoices provide the only dataset, which restricts the ability to verify savings from implemented measures. Greater data granularity would allow targeted tracking of SEUs, facilitate measurement and verification (M&V), and support compliance with ISO 50001 principles.”

Example 3:
“Current performance monitoring arrangements provide a partial view of energy use. While overall electricity and gas data are available from supplier invoices, regression analysis is constrained by gaps in metering and inconsistencies in boiler operation. Expanding sub-meter coverage to include prefabs, ICT loads, and major ventilation plant would allow more accurate allocation of energy use and support robust verification of savings from retrofit measures. Enhanced data capture would also help identify anomalies at an early stage, improving the overall effectiveness of energy management.”


