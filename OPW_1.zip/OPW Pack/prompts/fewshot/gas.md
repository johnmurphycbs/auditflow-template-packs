Example 1:
“Annual gas consumption was 64,000 kWh at a total cost of €18,400, based on 24 months of billing data. Peak demand was recorded in January, reflecting heating requirements during cold weather. Gas use followed a strong seasonal profile, with significant consumption from October through April and negligible demand in summer months. This pattern confirms that gas is primarily used for space heating, with only minor contributions from domestic hot water.”

Example 2:
“Thermal energy use peaks during the winter heating season due to radiator and AHU loads. Consumption reduces to near-zero in June, July, and August, highlighting the absence of year-round process demand. Improved time scheduling and tighter temperature control are recommended to reduce unnecessary operation during shoulder months. Weather compensation controls should also be reviewed to prevent overheating and improve comfort.”

Example 3:
“Regression analysis indicates a strong correlation between gas consumption and degree days, with an R² value above 0.7. This demonstrates predictable seasonal heating demand and highlights the potential for optimisation through better boiler sequencing and regular maintenance. Zero-consumption months in summer confirm that thermal loads are concentrated during occupied heating periods.”

Example 4:
“Gas demand is dominated by boiler plant serving space heating and hot water. While seasonal patterns are consistent with expectations, opportunities exist to reduce consumption through improved BMS scheduling and the introduction of lower setpoints during evenings and weekends. Enhanced metering would also provide better visibility of heating loads, enabling targeted monitoring of efficiency improvements.”


