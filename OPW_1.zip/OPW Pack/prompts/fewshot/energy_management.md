Example 1:
“Energy management at the site is supported by a central BMS controlling heating and ventilation systems. Schedules are generally aligned with occupancy, but there is scope to further refine setback temperatures and holiday shutdown modes. Periodic reviews of these parameters, ideally on a quarterly basis, would help ensure energy use continues to match operational needs.”

Example 2:
“Lighting remains largely controlled manually, leading to instances of fittings being left on outside of occupied hours. Extending the use of presence detection and time-switching would reduce wasted consumption. Behavioural engagement, including staff reminders and awareness campaigns, can complement technical measures to improve control discipline.”

Example 3:
“Governance arrangements are still at an early stage. While the site benefits from a BMS, there is no formal energy policy or structured energy team. Establishing a simple energy policy, supported by nominated local champions, would strengthen accountability and provide a clear framework for continuous improvement.”

Example 4:
“Metering coverage is limited to main utility meters, restricting visibility of individual SEUs. Expanding sub-metering, particularly for ICT, heating circuits, and prefabs, would allow better monitoring and facilitate verification of savings from energy efficiency projects. Improved data capture would also support compliance with ISO 50001 principles over time.”


