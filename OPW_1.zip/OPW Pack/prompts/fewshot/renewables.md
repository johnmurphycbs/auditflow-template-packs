Example 1:
“Rooftop solar PV has been modelled for the site, with an estimated annual generation of 7,945 kWh. This represents approximately 12% of total daytime electricity consumption and contributes to reduced grid imports during occupied hours. Generation follows a typical seasonal pattern, peaking between April and September and falling to lower levels during winter. The system therefore delivers the greatest benefit when teaching spaces are fully occupied and daytime demand is high.”

Example 2:
“Solar PV output shows a strong correlation with seasonal irradiance, with generation highest in late spring and summer. The system contributes directly to reducing grid purchases and helps to moderate peak daytime loads. Over the course of the year, the system offsets around €2,000 in electricity costs and avoids approximately 3 tonnes of CO₂ emissions. This supports the organisation’s decarbonisation objectives and compliance with energy efficiency frameworks.”

Example 3:
“While PV generation currently offsets a modest proportion of the site’s demand, it provides valuable resilience against future energy price increases. Aligning controllable loads, such as ventilation plant or hot water pre-heat, with PV availability would increase self-consumption and improve the return on investment. The system performance indicates potential to expand PV capacity, subject to roof area, orientation, and structural constraints.”

Example 4:
“Rooftop PV generation offsets a portion of daytime electricity demand. Output aligns with seasonal irradiance, providing greatest benefit in late spring and summer. Further optimisation of self-consumption can be achieved by aligning controllable loads with PV availability. Expansion of the array could be considered in future, particularly as technology costs continue to fall.”


