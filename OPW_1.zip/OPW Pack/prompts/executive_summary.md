Instruction
You are drafting the Executive Summary of an SI426 audit report. 
Write in a professional, factual tone consistent with OPW/SEAI reports. 
Use JSON data as the source. Target length: 400–600 words. 
Do not invent numbers. If values are missing, write a plausible but generic statement in the correct style. 
Never mention AI, placeholders, or uncertainty.

Constraints
- Tone: Professional, clear, concise.
- Units: kWh, €, %, kWh/m².
- Always write in third person with consistent tense and terminology.
- Banned words: “maybe”, “unclear”, “AI”, “placeholder”.
- Ensure at least 3–5 paragraphs are generated.

Mapping
Source JSON:
- data.meta (site_name, client_name, area_m2, report_date)
- data.energy_summary.electricity (total_kwh, total_cost_eur, months, peak_period)
- data.energy_summary.gas (total_kwh, total_cost_eur, months, peak_period)
- data.seu (list of significant energy users with name + percent)
- data.opportunities (list of measures, names and categories if available)

Narrative Target:
- Introduce the building, client, and purpose of the audit (compliance with SI426, overview of site).
- Summarise total annual energy consumption (electricity and gas) and associated costs.
- Highlight the most significant energy users (SEUs) and their contribution to demand.
- Summarise key opportunities identified, noting expected savings where available.
- Provide a concluding statement on potential carbon reduction and alignment with best practice energy management.

Few-shot Example
Example Executive Summary:
“This SI426 energy audit was carried out for a third-level education facility with a gross internal floor area of 2,800 m². The site recorded annual electricity consumption of 213,000 kWh (€27,600) and gas consumption of 64,000 kWh (€18,400) across a 23-month billing period. The largest energy uses were heating systems, which accounted for 90% of thermal demand, and ICT systems, which represented a significant share of electricity use.

The analysis of energy data highlighted seasonal variations, with peak electricity demand in October and peak gas consumption during the winter months. Total energy intensity was 40 kWh/m², broadly in line with benchmarks for this building type.

A range of opportunities have been identified to reduce consumption and costs. These include upgrading remaining fluorescent lighting to LED with controls, optimising heating schedules, and introducing on-site renewable generation. Collectively, these measures could achieve savings in the order of 15–20% of current consumption, with associated reductions in energy cost and carbon emissions.

Implementation of the recommended actions will support improved energy performance, reduced operating costs, and compliance with SEAI’s SI426 framework. The findings provide a clear roadmap for the client to enhance sustainability outcomes while maintaining service quality.”


