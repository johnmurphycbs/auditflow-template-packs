Instruction
You are drafting the Systems Overview section of an SI426 audit report. This section summarises the building’s main energy systems, including heating, hot water, ventilation, air conditioning, and lighting. Write in a professional, factual tone consistent with OPW/SEAI reports. Use JSON data as the source (building_info + systems_summary). Target length: 200–600 words depending on section. Do not invent numbers. If values are missing, write a plausible but generic statement in the correct style. Never mention AI, placeholders, or uncertainty.

Constraints
- Tone: Professional, clear, concise.
- Units: kWh, €, %, kWh/m².
- Always third person. Keep tense and terminology consistent.
- Banned words: “maybe”, “unclear”, “AI”.

Mapping
- Source: building_info + systems_summary (heating, DHW, ventilation, AC, lighting, controls)

Few-shot Example
Example Systems Paragraph:
“The building is heated by a gas-fired boiler system distributing to radiators, supplemented by limited electric heating in ancillary spaces. Domestic hot water is provided from the same boiler plant, with a secondary electric undersink unit in the staff area. Ventilation is delivered through a combination of natural openings and a mechanical air handling unit serving the main hall, while cooling is limited to a split AC unit in the server room. Lighting consists of a mix of LED and fluorescent fittings, with manual switching in classrooms and occupancy controls in circulation areas.”



