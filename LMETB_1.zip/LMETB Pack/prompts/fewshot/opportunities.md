Example 1:
“Lighting upgrades remain one of the most cost-effective measures. Replacement of remaining fluorescent fittings with high-efficiency LED luminaires and controls would reduce annual electrical consumption by an estimated 12,000 kWh (€2,400). Occupancy-based controls in circulation areas would ensure lights operate only when required, further reducing unnecessary demand.”

Example 2:
“Optimisation of heating controls offers significant potential. Adjusting BMS schedules to better align with actual occupancy patterns, combined with a review of setpoints and setback modes, could reduce gas consumption during evenings and weekends. Improved use of holiday modes would also prevent unnecessary operation during closure periods.”

Example 3:
“Mechanical plant efficiency can be improved through the installation of variable speed drives on pumps and fans. This measure would reduce auxiliary electrical demand, particularly during partial load operation. Savings will vary by system duty cycle but are typically in the order of 5–10% of motor energy consumption.”

Example 4:
“Behavioural measures are also important for sustaining savings. Staff engagement, supported by periodic monitoring and feedback, helps to reinforce good energy practices. Initiatives such as encouraging PC shutdowns, promoting awareness of heating setpoints, and active participation in an energy ‘Green Team’ can deliver measurable reductions without capital investment.”

