Example 1:
“This SI426 energy audit was carried out for a multi-storey public office facility with a gross internal floor area of 2,800 m². The audit reviewed electricity, gas, and ancillary energy uses in line with OPW/SEAI guidance. Annual electricity consumption was 213,000 kWh at a cost of €27,600, while gas demand totalled 64,000 kWh at €18,400. Together these represent an energy intensity of 40 kWh/m², broadly in line with benchmarks for this building type.”

Example 2:
“The analysis of energy data highlighted seasonal variation, with peak electricity demand recorded in October due to increased lighting and auxiliary heating loads. Gas use followed a clear seasonal pattern, with highest consumption in January and negligible use during summer. Significant Energy Users (SEUs) were identified as heating systems, ICT loads, and lighting, collectively accounting for the majority of annual demand.”

Example 3:
“A range of opportunities were identified to reduce consumption and costs. These include upgrading remaining fluorescent lighting to LED with occupancy controls, optimising heating schedules through the BMS, and installing variable speed drives on pumps and fans. Behavioural measures such as improved shutdown of ICT equipment and staff engagement in energy awareness campaigns will also support reductions. Collectively, these measures could achieve savings in the order of 15–20%.”

Example 4:
“The implementation of the recommended opportunities would deliver tangible benefits in terms of reduced energy cost and carbon emissions, while supporting compliance with the SI426 framework. The audit provides the client with a practical roadmap for energy performance improvement and highlights the importance of continuous monitoring and governance to sustain savings.”


