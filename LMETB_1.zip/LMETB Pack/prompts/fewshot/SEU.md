Example 1:
“Analysis of electrical consumption indicates that prefabs account for 41% of demand, reflecting high auxiliary heating and portable equipment usage. Lighting is the second largest load at 20%, followed by ICT equipment at 17%. Ventilation and air conditioning together represent a further 14%. These end uses dominate the site’s electrical profile and should be prioritised for energy efficiency measures.”

Example 2:
“Thermal energy consumption is driven almost entirely by space heating, which represents 90% of annual gas demand. Domestic hot water accounts for the remaining 10%. The high share of heating confirms the importance of improved boiler scheduling, setpoint management, and fabric upgrades in reducing overall demand.”

Example 3:
“Across both fuels, the heating system is the most significant energy user. Electrical SEUs include classroom lighting and ICT equipment, while thermal demand is concentrated in radiator heating. Sub-meter data is limited, but estimates indicate that over three-quarters of total energy use can be attributed to these systems. Targeted optimisation of these SEUs offers the greatest potential for savings.”

Example 4:
“SEU analysis shows that energy demand is concentrated in a small number of end uses. Lighting and ICT loads dominate the electrical profile, while heating accounts for the bulk of thermal consumption. These findings are consistent with the building type and occupancy profile, and provide a clear focus for the recommended opportunities.”
