Example 1:
“Space heating is provided by two gas boilers connected to a radiator distribution system. While thermostatic radiator valves are fitted in some areas, others remain uncontrolled, leading to potential overheating. The system operates on a timer with limited zoning, and there is scope for improvement in scheduling to match actual occupancy.”

Example 2:
“Domestic hot water is mainly produced by the central gas system, with one electric cylinder retained for backup. Hot water circulation is continuous during occupied hours, representing an opportunity for reduction through better control strategies or point-of-use generation.”

Example 3:
“Ventilation is primarily natural, supplemented by three air handling units with heat recovery. These units are manually scheduled, and observations during the site visit indicated that fans were operating in unoccupied areas. Variable speed control would provide improved efficiency.”

Example 4:
“Lighting remains a significant load, with approximately 70% of fittings upgraded to LED. Remaining fluorescent lamps are still in use in classrooms and ancillary areas. Lighting is mainly controlled manually, with PIR sensors installed in corridors and bathrooms. Opportunities exist to expand automatic controls to reduce unnecessary operation.”
