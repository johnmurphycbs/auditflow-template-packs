Example 1:
“Annual electricity consumption was 213,000 kWh at a total cost of €27,600, based on 23 months of billing data. The peak demand was observed in October, coinciding with shorter daylight hours and increased heating auxiliary loads. Monthly consumption remained broadly stable through the remainder of the year, with a modest reduction in July and August reflecting lower seasonal demand.”

Example 2:
“Time-of-use analysis indicates that 55% of demand occurred during the day and 45% at night. The daytime profile reflects office occupancy, teaching activity, and use of mechanical ventilation. Night-time load is primarily associated with ICT servers, standby equipment, and security systems. While the night share is typical for a site of this nature, there is potential to reduce base load through improved shutdown procedures.”

Example 3:
“Electricity intensity for the site equated to 38.9 kWh/m², which is broadly in line with benchmarks for education facilities. The data highlights opportunities for greater efficiency in both lighting and ICT loads. For example, upgrading remaining fluorescent fittings to LED with occupancy controls would reduce lighting demand, while promoting PC and monitor shutdown outside hours would address ICT base load.”

Example 4:
“Electrical demand exhibits a consistent base load associated with ICT and security systems, with higher daytime consumption linked to occupancy. Opportunities include LED retrofits, occupancy-based controls, and optimisation of air-handling units to reduce fan energy during partial loads. Collectively, these measures would improve efficiency while maintaining service quality.”


