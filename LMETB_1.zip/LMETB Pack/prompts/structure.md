Sections:

1. Executive Summary
   - Provide an overview of the building, key energy consumption figures, annual costs, and carbon impact.
   - Highlight the most significant energy uses and outline the main opportunities for savings.
   - Target length: 400–600 words.

2. Energy Use
   a) Electricity
      - Report annual consumption, cost, and number of billing months.
      - Highlight the peak consumption month and discuss day/night split.
      - Describe seasonal or monthly patterns.
      - Target length: 200–300 words.

   b) Gas
      - Report annual consumption, cost, and number of billing months.
      - Highlight the peak consumption month and link to seasonal heating demand.
      - Note zero-consumption months where applicable.
      - Target length: 200–300 words.

3. Significant Energy Users (SEUs)
   - Present the breakdown of energy use by SEU.
   - Identify dominant loads (e.g. heating, ICT, lighting).
   - Relate to building function and audit observations.
   - Target length: 150–250 words.

4. Renewables
   - Summarise renewable energy systems (mainly solar PV).
   - Report estimated generation and % coverage of demand.
   - Discuss seasonal patterns and contribution to costs and emissions.
   - Target length: 250–400 words.

5. Opportunities
   a) Introduction
      - Provide a short framing paragraph on the purpose of the opportunities list.
      - Mention the number and type of measures.
      - Target length: 120–200 words.

   b) Measures
      - Write a short paragraph for each opportunity describing the measure, rationale, and (if available) savings in kWh, € and %.
      - Target length: 100–200 words per measure.

6. Energy Management
   - Describe current management practices, BMS use, and control issues.
   - Note behavioural or organisational aspects relevant to energy use.
   - Target length: 150–250 words.

7. Performance Monitoring
   - Comment on regression analysis (R² values), energy intensities, and metering coverage.
   - Highlight gaps in monitoring and suggest improvements.
   - Target length: 300–500 words.

