Instruction
You are drafting the Gas section of an SI426 audit report. 
Write in a professional, factual tone consistent with OPW/SEAI reports. 
Use JSON data as the source. Target length: 250–400 words. 
Do not invent numbers. If values are missing, write a plausible but generic statement in the correct style. 
Never mention AI, placeholders, or uncertainty.

Constraints
- Tone: Professional, clear, concise.
- Units: kWh, €, %, kWh/m².
- Always write in third person with consistent tense and terminology.
- Banned words: “maybe”, “unclear”, “AI”, “placeholder”.
- Ensure at least 2–3 paragraphs are generated.

Mapping
Source JSON:
- data.energy_use.gas.annual_kwh
- data.energy_use.gas.annual_eur
- data.energy_use.gas.months
- data.energy_use.gas.peak_period
- data.energy_use.gas.periods (monthly breakdown for trend commentary)

Narrative Target:
- Report total annual gas consumption (kWh) and cost (€).
- State the number of billing months covered.
- Identify the peak month and link it to winter heating demand.
- Comment on seasonal variation, noting typical winter peaks and minimal summer use.
- Discuss how many months recorded zero consumption (if applicable).
- Provide a short commentary on the drivers of gas demand (e.g. boilers, AHUs, heating, DHW).
- End with a note on management implications (e.g. importance of controls, scheduling, or efficiency improvements).

Few-shot Example
Example Gas Paragraph:
“Annual gas consumption was 64,000 kWh at a total cost of €18,400, based on 24 months of billing data. Peak demand occurred in January, reflecting heating requirements during colder weather. Consumption followed a seasonal profile, with significant use from October through April and negligible demand during the summer months. Zero consumption was recorded in June, July, and August, confirming that gas is used primarily for space heating.

Boiler plant and associated AHU heating coils are the dominant end uses. The data highlights the importance of effective boiler scheduling and temperature setpoint control, particularly during shoulder seasons, to avoid unnecessary operation. Improved optimisation of heating controls would reduce out-of-hours consumption while maintaining comfort during occupied periods.”


