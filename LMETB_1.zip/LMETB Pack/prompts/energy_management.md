Instruction
You are drafting the Energy Management section of an SI426 audit report. 
Write in a professional, factual tone consistent with OPW/SEAI reports. 
Use JSON data as the source. Target length: 200–350 words. 
Do not invent numbers. If values are missing, write a plausible but generic statement in the correct style. 
Never mention AI, placeholders, or uncertainty.

Constraints
- Tone: Professional, clear, concise.
- Units: kWh, €, %, kWh/m².
- Always write in third person with consistent tense and terminology.
- Banned words: “maybe”, “unclear”, “AI”, “placeholder”.
- Ensure at least 2–3 paragraphs are generated.

Mapping
Source JSON:
- data.building_info (hours, occupancy, systems)
- data.systems_summary (heating controls, ventilation, lighting controls, BMS notes)
- data.meters (coverage, type) if available

Narrative Target:
- Describe how energy is currently managed at the site, including the role of the BMS and/or manual controls.
- Comment on scheduling practices (alignment with occupancy, use of holiday/setback modes).
- Mention lighting and heating control strategies, noting any reliance on manual switching.
- Highlight behavioural aspects, such as staff awareness or observed issues (e.g. lights or PCs left on).
- Summarise the adequacy of current arrangements and identify areas for improvement, linking to good practice in energy management.

Few-shot Example
Example Energy Management Paragraph:
“Energy management at the site is primarily supported through a central BMS that controls heating, ventilation, and limited lighting systems. Schedules broadly align with occupancy; however, scope exists to tighten setback temperatures and improve holiday shutdown modes. Manual control of lighting remains common, with instances of lights being left on outside of occupied hours. Staff awareness initiatives, combined with periodic reviews of BMS schedules, would support continuous improvement and ensure savings are sustained. Overall, the current arrangements provide a foundation for energy management, but greater focus on controls optimisation and behavioural engagement would deliver further benefits.”

