ExecutiveSummary — Use:
- data.meta (report_title, report_date, auditor, client_name, site_name, area_m2)
- data.energy_summary (electricity.total_kwh, electricity.total_cost_eur, gas.total_kwh, gas.total_cost_eur, highlights)
- data.site_notes (qualitative observations from site walkthrough; optional)
Narrative target:
- Summarise the site context, total annual energy consumption (electricity + gas), and overall energy costs.
- Highlight the peak consumption period and major SEUs.
- Reference relevant site observations when helpful.
Target length: 400–600 words.

EnergyUseElectricity — Use:
- data.energy_use.electricity (annual_kwh, annual_eur, months, peak_period)
- data.energy_use.electricity.tou (day_kwh, night_kwh)
Narrative target:
- Report annual electricity consumption and cost.
- Describe the highest consumption month and its significance.
- Discuss the day vs night split (% share of each).
- Comment on trends across the year (e.g. rising, falling, seasonal).
Target length: 200–300 words.

EnergyUseGas — Use:
- data.energy_use.gas (annual_kwh, annual_eur, months, peak_period)
Narrative target:
- Report annual gas consumption and cost.
- Highlight the peak month and link to seasonal heating demand.
- Discuss how many months gas was used (vs zero consumption in summer).
- Note any anomalies or unusual consumption patterns.
Target length: 200–300 words.

SEU_Table — Use:
- data.seu (list of significant energy users, name + percent + domain)
Narrative target:
- Present SEUs in order of size (largest first).
- Explain which systems are the dominant consumers.
- Relate SEUs to building function.
Target length: 150–250 words.

Renewables — Use:
- data.solar_pv (pv_kwh, coverage % against electricity demand, narrative if available)
Narrative target:
- Report estimated PV generation.
- Compare to site’s annual electricity use.
- Express as % coverage of demand.
- Add a short statement on suitability for renewables at the site.
Target length: 150–250 words.

OpportunitiesIntro — Use:
- data.opportunities (list length, categories if available)
- data.site_notes (contextual notes that set up measures)
Narrative target:
- Provide a short framing paragraph introducing the opportunities.
- Mention that they are based on site walkthroughs, data, and best practice.
Target length: 100–150 words.

Opportunities — Use:
- data.opportunities (each with name, description, potential savings if available)
- data.site_notes (cross-check qualitative details observed on site)
Narrative target:
- Write a structured narrative for each opportunity.
- For each: describe the measure, explain the rationale, and (if given) mention savings in kWh, EUR or %.
- Keep each measure ~100–200 words.

EnergyManagement — Use:
- data.site_notes (behaviours, control issues, BMS observations; optional)
Narrative target:
- Summarise current energy management practices, controls, and any issues noted during the audit.
- Reference specific observations from site notes where helpful.
Target length: 150–250 words.

